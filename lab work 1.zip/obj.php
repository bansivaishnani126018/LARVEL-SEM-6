</html>
<body>
    <h1> the fruit program</h1>

<?php
     class frutic{

     public$name;
     public$color;

     function set_name($name) {
        $this->name = $name;
     }

     function get_name() {
        return $this->name;
     }
     }
     $apple = new frutic();
     $banana = new frutic();
     $apple->set_name('Apple');
     $banana->set_name('banana');

     echo $apple->get_name();
     echo"<br>";
     echo$banana->get_name();
   ?>
   
</body>
</html>